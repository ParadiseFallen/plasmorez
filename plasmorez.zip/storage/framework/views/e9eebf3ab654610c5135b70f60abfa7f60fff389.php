<?php $__env->startSection('body'); ?>
    <section id="first-screen">
        <iframe class="ratio ratio-16x9" src="https://www.youtube.com/embed/JCnpxtKkVjQ?controls=0&showinfo=0" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            
    </section>

    <?php echo $__env->make('partials/order-card',['data'=>''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('partials/call-me', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('partials/little-gallery',['gallery' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    

    <section id="works" class="my-2">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 class="section-header text-center">
                        Фото нашего оборудования <br> и выполненных работ.
                    </h1>
                </div>
            </div>
            <div class="row">
                <?php for($i = 0; $i<3; $i++): ?>
                    <div class="col-md-4 justify-content-center align-items-center d-flex my-2">
                        <div class="project-card">
                            <div class="project-card-inner d-flex flex-column">
                                <div class="project-card-inner-img">
                                    <div>
                                        <img src="/img/work-1.jpg" alt="" class="img-fluid">
                                    </div>
                                </div>
                                <div class="project-card-inner-text text-center p-2 d-flex justify-content-center align-items-center">
                                    <p>Оборудование</p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endfor; ?>
            </div>
        </div>
    </section>
    <?php echo $__env->make('partials/features',['data'=>''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('partials/order-card',['data'=>''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\desktop\plasmorez\resources\views/index.blade.php ENDPATH**/ ?>