<section id="mini-blog">
    <div class="container">
        <?php for($i = 0; $i < 6; $i++): ?>
        <div class="row data-row align-items-center my-2">
            <div class="col-lg-8 my-2 order-1">
                <div class="data-card d-flex flex-column px-3">
                    <h2>Декоративная резка металла плазморезом</h2>
                    <p>Декоративная резка плазморезом. Легкие каминные решетки, изящные перила с причудливыми узорами, декор, зеркала в ажурных рамах, декоративные ограждения и заборы все это в последнее время активно используется в дизайне интерьера. </p>
                    <p>Художественные изделия из металла могут украсить не только любой дом или квартиру, но и стать оригинальным решением в дизайне интерьеров кафе, офисов и ресторанов. С помощью художественной резки металла можно создавать надписи, логотипы, рекламные вывески, что выгодно подчеркнет фирменный стиль компании.</p>
                </div>
            </div>
            <div class="col-lg-4 my-2 img-col">
                <div class="brackets p-3">
                    <img src="/img/wire.png" alt="" class="img-fluid">
                </div>
            </div>
        </div>
        <?php endfor; ?>
    </div>
</section>
<?php /**PATH C:\desktop\plasmorez\resources\views/mini-blog.blade.php ENDPATH**/ ?>