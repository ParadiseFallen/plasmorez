
<section id="plasm-info" class="my-md-4 my-2">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 d-flex flex-column align-items-center">
                <div class="data-card d-flex flex-column">
                    <h2><?php echo e($data->header); ?></h2>
                    <?php echo $data->description; ?>

                </div>
                <a href="#" class="dark-btn my-md-4 my-1" onclick="callPopup(event)">Заказать</a>
            </div>
            <div class="col-lg-6 <?php if(!isset($reverse)): ?> order-lg-last <?php endif; ?> order-first">
                <div class="brackets m-3">
                    <img src="<?php echo e($data->image); ?>" alt="" class="img-fluid m-4">
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\desktop\plasmorez\resources\views/components/order-card.blade.php ENDPATH**/ ?>