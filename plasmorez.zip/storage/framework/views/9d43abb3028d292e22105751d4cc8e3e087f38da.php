<section id="call-me">
    <form action="">
        <div class="container">
            <div class="row py-4 align-items-center d-">
                <div class="col-md-7">
                    <input type="tel" class="w-100" name="phone" placeholder="Введите ваш телефон">
                </div>
                <div class="col-md-4 offset-md-1 my-2">
                    <button type="submit" class="white-btn">Мы перезвоним</button>
                </div>
            </div>
        </div>
    </form>
</section>
<?php /**PATH C:\desktop\plasmorez\resources\views/partials/call-me.blade.php ENDPATH**/ ?>