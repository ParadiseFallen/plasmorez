<section id="mini-blog">
    <div class="container">
        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row data-row align-items-center my-2">
            <div class="col-lg-8 my-2 order-1">
                <div class="data-card d-flex flex-column px-3">
                    <h2><?php echo e($record->header); ?></h2>
                    <?php echo e(htmlspecialchars_decode($record->text)); ?>

                </div>
            </div>
            <div class="col-lg-4 my-2 img-col">
                <div class="brackets p-3">
                    <img src="/img/wire.png" alt="" class="img-fluid">
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php /**PATH C:\desktop\plasmorez\resources\views/partials/mini-blog.blade.php ENDPATH**/ ?>